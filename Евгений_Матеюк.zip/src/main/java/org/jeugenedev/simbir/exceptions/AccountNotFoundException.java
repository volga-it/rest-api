package org.jeugenedev.simbir.exceptions;

public class AccountNotFoundException extends RuntimeException {
}
