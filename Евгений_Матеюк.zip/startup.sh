mvn clean package &&
java -jar ./target/simbir.jar